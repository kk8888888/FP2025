// This file has been renamed to appConstants.ts to resolve a module loading conflict.

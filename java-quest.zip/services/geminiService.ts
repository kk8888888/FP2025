
import { GoogleGenAI, Type } from "@google/genai";
import { QuizQuestion, CodeScrambleChallenge, BugHuntChallenge } from '../types';
import { TOTAL_QUESTIONS_PER_QUIZ } from '../appConstants.ts';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

// --- QUIZ ---
const quizResponseSchema = {
  type: Type.ARRAY,
  description: `An array of ${TOTAL_QUESTIONS_PER_QUIZ} quiz questions.`,
  items: {
    type: Type.OBJECT,
    properties: {
      question: { type: Type.STRING, description: "The question text, including any code snippets formatted with markdown backticks." },
      options: { type: Type.ARRAY, description: "An array of exactly 4 string options.", items: { type: Type.STRING } },
      answer: { type: Type.STRING, description: "The correct answer, which must exactly match one of the provided options." },
      explanation: { type: Type.STRING, description: "A brief and clear explanation of why the answer is correct." },
    },
    required: ["question", "options", "answer", "explanation"],
  },
};

export const generateJavaQuizQuestions = async (): Promise<QuizQuestion[]> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: `Generate ${TOTAL_QUESTIONS_PER_QUIZ} unique and high-quality multiple-choice quiz questions about core Java concepts (e.g., variables, loops, methods, basic OOP, data types). For each question, provide a question, 4 options, the correct answer, and an explanation. Ensure code snippets are concise and well-formatted.`,
      config: { responseMimeType: "application/json", responseSchema: quizResponseSchema, temperature: 0.8, },
    });
    return JSON.parse(response.text.trim());
  } catch (error) {
    console.error("Error generating quiz questions:", error);
    return [{ question: "What is the output of `System.out.println(10 / 2);`?", options: ["5", "2", "10", "Error"], answer: "5", explanation: "The `/` operator performs division. 10 divided by 2 is 5." }];
  }
};


// --- CODE SCRAMBLE ---
const codeScrambleSchema = {
  type: Type.OBJECT,
  properties: {
    scrambledLines: { type: Type.ARRAY, description: "An array of 4-6 shuffled lines of Java code.", items: { type: Type.STRING } },
    correctOrder: { type: Type.ARRAY, description: "The same lines of code but in the correct logical order.", items: { type: Type.STRING } },
    explanation: { type: Type.STRING, description: "A brief explanation of what the corrected code does." },
  },
  required: ["scrambledLines", "correctOrder", "explanation"],
};

export const generateCodeScrambleChallenge = async (): Promise<CodeScrambleChallenge> => {
    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: `Generate a simple but logical Java code snippet for a common task (like a loop, simple method, or variable declaration) consisting of 4 to 5 lines. Provide the lines as two separate arrays in a JSON object: one array with the lines scrambled, and another with the lines in the correct order. Also include a brief explanation of the code's purpose.`,
            config: { responseMimeType: "application/json", responseSchema: codeScrambleSchema, temperature: 0.7, },
        });
        return JSON.parse(response.text.trim());
    } catch (error) {
        console.error("Error generating code scramble challenge:", error);
        return {
            scrambledLines: ["System.out.println(i);", "for (int i = 1; i <= 3; i++) {", "}", "public static void main(String[] args) {"],
            correctOrder: ["public static void main(String[] args) {", "for (int i = 1; i <= 3; i++) {", "System.out.println(i);", "}"],
            explanation: "This code defines a main method that loops from 1 to 3, printing the value of 'i' in each iteration."
        };
    }
};

// --- BUG HUNT ---
const bugHuntSchema = {
    type: Type.OBJECT,
    properties: {
        code: { type: Type.ARRAY, description: "An array of 5-7 lines of Java code containing a single, subtle bug.", items: { type: Type.STRING } },
        buggyLine: { type: Type.INTEGER, description: "The 1-based line number that contains the bug." },
        explanation: { type: Type.STRING, description: "A clear explanation of the bug and how to fix it." },
    },
    required: ["code", "buggyLine", "explanation"],
};

export const generateBugHuntChallenge = async (): Promise<BugHuntChallenge> => {
    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: `Generate a simple Java code snippet of 5 to 7 lines containing a single, common, and subtle bug (e.g., off-by-one in a loop, using '=' instead of '==' in a condition, wrong variable in a print statement, or a simple type mismatch). Provide the code as an array of strings, the 1-based line number with the bug, and a clear explanation of the error.`,
            config: { responseMimeType: "application/json", responseSchema: bugHuntSchema, temperature: 0.9, },
        });
        return JSON.parse(response.text.trim());
    } catch (error) {
        console.error("Error generating bug hunt challenge:", error);
        return {
            code: [
                "public class BugExample {",
                "  public static void main(String[] args) {",
                "    int[] numbers = {10, 20, 30};",
                "    for (int i = 0; i <= numbers.length; i++) {",
                "      System.out.println(numbers[i]);",
                "    }",
                "  }",
                "}"
            ],
            buggyLine: 4,
            explanation: "The loop condition `i <= numbers.length` causes an `ArrayIndexOutOfBoundsException` because array indices go from 0 to length-1. The condition should be `i < numbers.length`."
        };
    }
};

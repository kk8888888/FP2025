
import React from 'react';
import { CodeIcon } from './Icons';

interface HomeScreenProps {
  onShowLevels: () => void;
}

const HomeScreen: React.FC<HomeScreenProps> = ({ onShowLevels }) => {
  return (
    <div className="text-center bg-slate-800/50 p-10 rounded-2xl shadow-2xl backdrop-blur-lg border border-slate-700 animate-fade-in">
      <div className="flex justify-center items-center mb-6">
        <CodeIcon className="w-24 h-24 text-cyan-400" />
      </div>
      <h1 className="text-5xl font-extrabold mb-4 text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-500">
        Welcome to Java Quest
      </h1>
      <p className="text-slate-300 text-lg max-w-2xl mx-auto mb-8">
        Test your Java knowledge with our interactive quiz. Earn points for correct answers,
        track your progress, and redeem your points for cool virtual rewards!
      </p>
      <button
        onClick={onShowLevels}
        className="px-12 py-4 bg-gradient-to-r from-green-500 to-teal-500 text-white font-bold text-xl rounded-full shadow-lg transform transition-transform duration-300 hover:scale-110 hover:shadow-2xl focus:outline-none focus:ring-4 focus:ring-green-300"
      >
        Begin Your Quest
      </button>
    </div>
  );
};

export default HomeScreen;

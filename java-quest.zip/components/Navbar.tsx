
import React from 'react';
import { HeartIcon, StarIcon, GiftIcon, CodeIcon } from './Icons';

interface NavbarProps {
  score: number;
  lives: number;
  onStoreClick: () => void;
  onHomeClick: () => void;
  isGameActive: boolean;
}

const Navbar: React.FC<NavbarProps> = ({ score, lives, onStoreClick, onHomeClick, isGameActive }) => {
  return (
    <header className="w-full max-w-6xl p-4 bg-slate-800/50 backdrop-blur-sm rounded-xl fixed top-4 z-50 flex items-center justify-between shadow-lg">
      <button onClick={onHomeClick} className="flex items-center gap-2 text-xl font-bold text-cyan-400 hover:text-cyan-300 transition-colors">
        <CodeIcon className="w-7 h-7" />
        Java Quest
      </button>
      <div className="flex items-center gap-6">
        {(isGameActive || score > 0) && (
          <div className="flex items-center gap-2">
            <StarIcon className="w-6 h-6 text-yellow-400" />
            <span className="text-xl font-semibold text-white">{score}</span>
          </div>
        )}
        {isGameActive && (
          <div className="flex items-center gap-2">
            {[...Array(lives)].map((_, i) => (
              <HeartIcon key={i} className="w-6 h-6 text-red-500 animate-pulse" />
            ))}
            {[...Array(Math.max(0, 3 - lives))].map((_, i) => (
                <HeartIcon key={i} className="w-6 h-6 text-slate-600" />
            ))}
          </div>
        )}
        <button
          onClick={onStoreClick}
          className="bg-purple-600 text-white font-semibold px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-purple-700 transition-all transform hover:scale-105 shadow-md"
        >
          <GiftIcon className="w-5 h-5" />
          <span>Rewards</span>
        </button>
      </div>
    </header>
  );
};

export default Navbar;

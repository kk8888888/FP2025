
import React from 'react';
import { Level, GameType } from '../types';
import { LockIcon, PlayIcon } from './Icons';

interface LevelSelectScreenProps {
  levels: Level[];
  unlockedLevels: Set<number>;
  onSelectLevel: (levelId: number) => void;
}

const GameTypeIcon = ({ gameType }: { gameType: GameType }) => {
    const commonClass = "w-5 h-5 mr-2"
    if (gameType === GameType.QUIZ) return <span className={commonClass}>📝</span>
    if (gameType === GameType.CODE_SCRAMBLE) return <span className={commonClass}>🔀</span>
    if (gameType === GameType.BUG_HUNT) return <span className={commonClass}>🐞</span>
    return null;
}

const LevelSelectScreen: React.FC<LevelSelectScreenProps> = ({ levels, unlockedLevels, onSelectLevel }) => {
  return (
    <div className="w-full max-w-5xl p-8 bg-slate-800/60 rounded-2xl shadow-2xl backdrop-blur-lg border border-slate-700 animate-fade-in">
      <h1 className="text-4xl font-bold text-center text-cyan-400 mb-8">Select a Level</h1>
      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-5">
        {levels.map(level => {
          const isUnlocked = unlockedLevels.has(level.id);
          return (
            <button
              key={level.id}
              onClick={() => isUnlocked && onSelectLevel(level.id)}
              disabled={!isUnlocked}
              className={`p-4 rounded-xl text-left transition-all duration-300 transform flex flex-col justify-between aspect-square
                ${isUnlocked 
                    ? 'bg-slate-700 hover:bg-slate-600 hover:shadow-cyan-400/30 hover:-translate-y-1 shadow-lg border border-slate-600 cursor-pointer' 
                    : 'bg-slate-800/50 border border-slate-700 cursor-not-allowed'
                }`
              }
            >
              <div>
                <div className={`flex items-center justify-between mb-2 ${isUnlocked ? 'text-cyan-400' : 'text-slate-500'}`}>
                  <span className="text-2xl font-bold">
                    {level.id}
                  </span>
                  {isUnlocked ? <PlayIcon className="w-6 h-6 text-green-400" /> : <LockIcon className="w-6 h-6 text-slate-500"/>}
                </div>
                <h3 className={`font-semibold text-base ${isUnlocked ? 'text-white' : 'text-slate-500'}`}>{level.title}</h3>
              </div>
              <div>
                <div className={`flex items-center text-xs mt-3 ${isUnlocked ? 'text-slate-400' : 'text-slate-600'}`}>
                    <GameTypeIcon gameType={level.gameType} />
                    <span>{level.gameType}</span>
                </div>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};

export default LevelSelectScreen;

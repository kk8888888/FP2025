
import React from 'react';
import { Gift, IconId } from '../types';
import { GIFT_ITEMS } from '../appConstants.ts';
import { StarIcon, CoffeeIcon, GiftIcon, TrophyIcon, CodeIcon } from './Icons';

interface StoreScreenProps {
  score: number;
  redeemedGifts: number[];
  onRedeem: (gift: Gift) => void;
  onBack: () => void;
}

const GiftIconDisplay: React.FC<{ iconId: IconId }> = ({ iconId }) => {
  const className = "w-8 h-8";
  switch (iconId) {
    case 'coffee': return <CoffeeIcon className={className} />;
    case 'gift': return <GiftIcon className={className} />;
    case 'code': return <CodeIcon className={className} />;
    case 'trophy': return <TrophyIcon className={className} />;
    default: return null;
  }
};

const StoreScreen: React.FC<StoreScreenProps> = ({ score, redeemedGifts, onRedeem, onBack }) => {
  return (
    <div className="w-full max-w-4xl p-8 bg-slate-800/60 rounded-2xl shadow-2xl backdrop-blur-lg border border-slate-700 animate-fade-in">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-4xl font-bold text-purple-400">Rewards Store</h1>
        <div className="flex items-center gap-3 bg-slate-900 px-4 py-2 rounded-lg">
          <StarIcon className="w-8 h-8 text-yellow-400" />
          <span className="text-3xl font-bold text-white">{score}</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {GIFT_ITEMS.map((gift) => {
          const isRedeemed = redeemedGifts.includes(gift.id);
          const canAfford = score >= gift.cost;

          return (
            <div
              key={gift.id}
              className={`p-6 rounded-xl flex flex-col items-center justify-between transition-all duration-300 ${isRedeemed ? 'bg-green-800/50 border border-green-600' : 'bg-slate-700 border border-transparent'}`}
            >
              <div className="text-purple-300 mb-4"><GiftIconDisplay iconId={gift.iconId} /></div>
              <h3 className="text-lg font-semibold text-white mb-2 text-center h-12 flex items-center">{gift.name}</h3>
              <div className="flex items-center gap-1 text-yellow-400 mb-4">
                <StarIcon className="w-5 h-5" />
                <span className="font-bold">{gift.cost}</span>
              </div>
              <button
                onClick={() => onRedeem(gift)}
                disabled={isRedeemed || !canAfford}
                className={`w-full py-2 px-4 rounded-lg font-bold transition-colors text-white ${
                  isRedeemed 
                    ? 'bg-green-500 cursor-not-allowed' 
                    : canAfford 
                      ? 'bg-purple-600 hover:bg-purple-700' 
                      : 'bg-slate-500 cursor-not-allowed text-slate-400'
                }`}
              >
                {isRedeemed ? 'Redeemed' : 'Redeem'}
              </button>
            </div>
          );
        })}
      </div>
      
      <div className="text-center mt-10">
        <button 
          onClick={onBack}
          className="bg-slate-600 text-white font-semibold px-6 py-2 rounded-lg hover:bg-slate-500 transition-colors"
        >
          Back to Levels
        </button>
      </div>
    </div>
  );
};

export default StoreScreen;

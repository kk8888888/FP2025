
import React, { useState, useEffect, useCallback } from 'react';
import { generateJavaQuizQuestions } from '../services/geminiService';
import { QuizQuestion } from '../types';
import { POINTS_PER_CORRECT_ANSWER, TOTAL_QUESTIONS_PER_QUIZ } from '../appConstants.ts';

interface QuizMiniGameProps {
  setScore: React.Dispatch<React.SetStateAction<number>>;
  setLives: React.Dispatch<React.SetStateAction<number>>;
  onComplete: (success: boolean) => void;
  initialLives: number;
}

const QuizScreen: React.FC<QuizMiniGameProps> = ({ setScore, setLives, onComplete, initialLives }) => {
  const [questions, setQuestions] = useState<QuizQuestion[]>([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchQuestions = async () => {
      setIsLoading(true);
      const fetchedQuestions = await generateJavaQuizQuestions();
      setQuestions(fetchedQuestions.slice(0, TOTAL_QUESTIONS_PER_QUIZ));
      setIsLoading(false);
    };
    fetchQuestions();
  }, []);

  const handleAnswerSelect = (option: string) => {
    if (isAnswered) return;
    setSelectedAnswer(option);
    setIsAnswered(true);

    if (option === questions[currentQuestionIndex].answer) {
      setScore(prev => prev + POINTS_PER_CORRECT_ANSWER);
    } else {
      setLives(prev => {
        if (prev - 1 <= 0) {
          // The App component will catch the 0 lives state
        }
        return prev - 1;
      });
    }
  };
  
  const handleNextQuestion = useCallback(() => {
    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
      setSelectedAnswer(null);
      setIsAnswered(false);
    } else {
      onComplete(true); // Quiz finished with lives remaining
    }
  }, [currentQuestionIndex, questions.length, onComplete]);

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center text-white">
        <div className="w-16 h-16 border-4 border-dashed rounded-full animate-spin border-cyan-400"></div>
        <p className="mt-4 text-lg">Generating Your Java Challenge...</p>
      </div>
    );
  }

  if (questions.length === 0) {
    return <div className="text-center text-red-400">Failed to load questions. Please try again later.</div>;
  }
  
  const currentQuestion = questions[currentQuestionIndex];
  const progressPercentage = ((currentQuestionIndex + 1) / TOTAL_QUESTIONS_PER_QUIZ) * 100;

  const getButtonClass = (option: string) => {
    if (!isAnswered) return 'bg-slate-700 hover:bg-slate-600 text-white';
    if (option === currentQuestion.answer) return 'bg-green-600 animate-pulse text-white';
    if (option === selectedAnswer && option !== currentQuestion.answer) return 'bg-red-600 text-white';
    return 'bg-slate-700 opacity-50 text-slate-300';
  };

  return (
    <div className="w-full max-w-3xl animate-fade-in">
      <div className="mb-6">
        <div className="flex justify-between items-center mb-2 text-slate-300">
          <span>Question {currentQuestionIndex + 1} of {TOTAL_QUESTIONS_PER_QUIZ}</span>
        </div>
        <div className="w-full bg-slate-700 rounded-full h-2.5">
          <div className="bg-cyan-400 h-2.5 rounded-full transition-all duration-500" style={{ width: `${progressPercentage}%` }}></div>
        </div>
      </div>
      
      <div className="mb-6">
        <h2 className="text-2xl font-semibold text-slate-100 mb-4">{currentQuestion.question.split('`').map((part, i) => i % 2 === 1 ? <code key={i} className="bg-slate-900 text-cyan-300 rounded-md px-2 py-1 font-mono">{part}</code> : <span key={i}>{part}</span>)}</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {currentQuestion.options.map((option, index) => (
            <button
              key={index}
              onClick={() => handleAnswerSelect(option)}
              disabled={isAnswered}
              className={`p-4 rounded-lg text-left font-medium transition-all duration-300 transform focus:outline-none focus:ring-2 focus:ring-cyan-400 ${getButtonClass(option)}`}
            >
              {option.split('`').map((part, i) => i % 2 === 1 ? <code key={i} className="bg-slate-900/50 text-cyan-200 rounded-md px-1 font-mono">{part}</code> : <span key={i}>{part}</span>)}
            </button>
          ))}
        </div>
      </div>

      {isAnswered && (
        <div className="mt-6 p-4 rounded-lg bg-slate-900 animate-fade-in">
          <h3 className="font-bold text-lg mb-2 text-cyan-400">Explanation</h3>
          <p className="text-slate-300">{currentQuestion.explanation}</p>
          <button
            onClick={handleNextQuestion}
            className="mt-4 w-full bg-purple-600 text-white font-bold py-3 px-4 rounded-lg hover:bg-purple-700 transition-colors transform hover:scale-105"
          >
            {currentQuestionIndex < questions.length - 1 ? 'Next Question' : 'Finish Quiz'}
          </button>
        </div>
      )}
    </div>
  );
};

export default QuizScreen;


import React from 'react';
import { StarIcon } from './Icons';

interface GameOverScreenProps {
  score: number;
  onRestartGame: () => void;
}

const GameOverScreen: React.FC<GameOverScreenProps> = ({ score, onRestartGame }) => {
  return (
    <div className="text-center bg-slate-800/50 p-10 rounded-2xl shadow-2xl backdrop-blur-lg border border-slate-700 animate-fade-in">
      <h1 className="text-6xl font-extrabold mb-4 text-red-500">Game Over</h1>
      <p className="text-slate-300 text-xl mb-6">You've run out of lives.</p>
      <div className="flex flex-col items-center justify-center bg-slate-900 p-6 rounded-lg mb-8">
        <p className="text-lg text-slate-400">Your Final Score</p>
        <div className="flex items-center gap-3 mt-2">
          <StarIcon className="w-10 h-10 text-yellow-400" />
          <span className="text-5xl font-bold text-white">{score}</span>
        </div>
      </div>
      <button
        onClick={onRestartGame}
        className="px-10 py-3 bg-gradient-to-r from-cyan-500 to-blue-500 text-white font-bold text-lg rounded-full shadow-lg transform transition-transform duration-300 hover:scale-110 hover:shadow-2xl focus:outline-none focus:ring-4 focus:ring-cyan-300"
      >
        Restart Quest
      </button>
    </div>
  );
};

export default GameOverScreen;

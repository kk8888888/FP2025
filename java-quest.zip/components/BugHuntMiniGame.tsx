
import React, { useState } from 'react';
import { BugHuntChallenge } from '../types';
import { POINTS_PER_CORRECT_ANSWER } from '../appConstants';

interface BugHuntMiniGameProps {
  challenge: BugHuntChallenge;
  setScore: React.Dispatch<React.SetStateAction<number>>;
  setLives: React.Dispatch<React.SetStateAction<number>>;
  onComplete: (success: boolean) => void;
}

const BugHuntMiniGame: React.FC<BugHuntMiniGameProps> = ({ challenge, setScore, setLives, onComplete }) => {
  const [selectedLine, setSelectedLine] = useState<number | null>(null);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const isCorrect = selectedLine === challenge.buggyLine;

  const handleLineClick = (lineNumber: number) => {
    if (isSubmitted) return;
    setSelectedLine(lineNumber);

    const correct = lineNumber === challenge.buggyLine;
    setIsSubmitted(true);
    
    if (correct) {
      setScore(prev => prev + POINTS_PER_CORRECT_ANSWER * 2);
    } else {
      setLives(prev => prev - 1);
    }
  };

  const getLineClassName = (lineNumber: number) => {
    if (!isSubmitted) {
        return 'hover:bg-slate-700 cursor-pointer';
    }
    if (lineNumber === challenge.buggyLine) {
        return 'bg-green-900/70 border-l-4 border-green-500';
    }
    if (lineNumber === selectedLine && lineNumber !== challenge.buggyLine) {
        return 'bg-red-900/70 border-l-4 border-red-500';
    }
    return 'opacity-60';
  }


  return (
    <div className="w-full max-w-3xl animate-fade-in">
      <div className="mb-6">
        <h2 className="text-xl font-semibold text-slate-100 mb-4">Find the bug! Click on the line of code that is incorrect.</h2>
        <div className="bg-slate-900 p-4 rounded-lg font-mono text-slate-300">
            {challenge.code.map((line, index) => {
                const lineNumber = index + 1;
                return (
                    <div key={index} onClick={() => handleLineClick(lineNumber)} className={`flex items-start gap-4 p-2 rounded transition-colors ${getLineClassName(lineNumber)}`}>
                       <span className="select-none text-right w

import React, { useState, useEffect, useCallback } from 'react';
import { Level, GameType, QuizQuestion, CodeScrambleChallenge, BugHuntChallenge } from '../types';
import { generateJavaQuizQuestions, generateCodeScrambleChallenge, generateBugHuntChallenge } from '../services/geminiService';
import QuizScreen from './QuizScreen';
import CodeScrambleMiniGame from './CodeScrambleMiniGame';
import BugHuntMiniGame from './BugHuntMiniGame';
import LevelCompleteModal from './LevelCompleteModal';
import { POINTS_PER_CORRECT_ANSWER } from '../appConstants';

interface GameScreenProps {
  level: Level;
  score: number;
  setScore: React.Dispatch<React.SetStateAction<number>>;
  lives: number;
  setLives: React.Dispatch<React.SetStateAction<number>>;
  onGameEnd: (newScore: number, success: boolean) => void;
}

const GameScreen: React.FC<GameScreenProps> = ({ level, score, setScore, lives, setLives, onGameEnd }) => {
  const [challengeData, setChallengeData] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isComplete, setIsComplete] = useState(false);
  const [scoreAtStart] = useState(score);

  useEffect(() => {
    const fetchChallenge = async () => {
      setIsLoading(true);
      let data;
      switch (level.gameType) {
        case GameType.QUIZ:
          data = await generateJavaQuizQuestions();
          break;
        case GameType.CODE_SCRAMBLE:
          data = await generateCodeScrambleChallenge();
          break;
        case GameType.BUG_HUNT:
            data = await generateBugHuntChallenge();
            break;
        default:
          console.error("Unknown game type:", level.gameType);
      }
      setChallengeData(data);
      setIsLoading(false);
    };
    fetchChallenge();
  }, [level]);

  const handleMiniGameComplete = useCallback((success: boolean) => {
    if (success) {
      setIsComplete(true);
    } 
    // Failure (running out of lives) is handled at the App level
  }, []);
  
  const handleContinue = () => {
    onGameEnd(score, true);
  };
  
  const renderMiniGame = () => {
    if (!challengeData) return null;

    switch (level.gameType) {
      case GameType.QUIZ:
        return <QuizScreen setScore={setScore} setLives={setLives} onComplete={handleMiniGameComplete} initialLives={lives} />;
      case GameType.CODE_SCRAMBLE:
          return <CodeScrambleMiniGame challenge={challengeData} setScore={setScore} setLives={setLives} onComplete={handleMiniGameComplete} />
      case GameType.BUG_HUNT:
          return <BugHuntMiniGame challenge={challengeData} setScore={setScore} setLives={setLives} onComplete={handleMiniGameComplete} />
      default:
        return <div className="text-red-500">Error: Unknown game type.</div>;
    }
  };

  return (
     <div className="w-full max-w-3xl p-8 bg-slate-800/60 rounded-2xl shadow-2xl backdrop-blur-lg border border-slate-700">
        <h1 className="text-3xl font-bold text-center text-cyan-400 mb-2">Level {level.id}: {level.title}</h1>
        <p className="text-center text-slate-300 mb-6">{level.description}</p>
      {isLoading ? (
        <div className="flex flex-col items-center justify-center text-white h-64">
          <div className="w-16 h-16 border-4 border-dashed rounded-full animate-spin border-cyan-400"></div>
          <p className="mt-4 text-lg">Generating Your Java Challenge...</p>
        </div>
      ) : (
        renderMiniGame()
      )}
      {isComplete && (
        <LevelCompleteModal 
          scoreGained={score - scoreAtStart}
          onContinue={handleContinue}
        />
      )}
    </div>
  );
};

export default GameScreen;

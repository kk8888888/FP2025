
import React, { useState, useMemo } from 'react';
import { CodeScrambleChallenge } from '../types';
import { POINTS_PER_CORRECT_ANSWER } from '../appConstants';

interface CodeScrambleMiniGameProps {
  challenge: CodeScrambleChallenge;
  setScore: React.Dispatch<React.SetStateAction<number>>;
  setLives: React.Dispatch<React.SetStateAction<number>>;
  onComplete: (success: boolean) => void;
}

const CodeScrambleMiniGame: React.FC<CodeScrambleMiniGameProps> = ({ challenge, setScore, setLives, onComplete }) => {
  const [userOrder, setUserOrder] = useState<string[]>(challenge.scrambledLines);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isCorrect, setIsCorrect] = useState(false);

  const moveLine = (index: number, direction: 'up' | 'down') => {
    const newOrder = [...userOrder];
    const targetIndex = direction === 'up' ? index - 1 : index + 1;

    if (targetIndex < 0 || targetIndex >= newOrder.length) return;

    [newOrder[index], newOrder[targetIndex]] = [newOrder[targetIndex], newOrder[index]];
    setUserOrder(newOrder);
  };

  const handleSubmit = () => {
    const correct = JSON.stringify(userOrder) === JSON.stringify(challenge.correctOrder);
    setIsCorrect(correct);
    setIsSubmitted(true);

    if (correct) {
      setScore(prev => prev + POINTS_PER_CORRECT_ANSWER * 2); // More points for a harder challenge
    } else {
      setLives(prev => prev - 1);
    }
  };

  return (
    <div className="w-full max-w-3xl animate-fade-in">
      <div className="mb-6">
        <h2 className="text-xl font-semibold text-slate-100 mb-4">Unscramble the code to make it work correctly:</h2>
        <div className="bg-slate-900 p-4 rounded-lg font-mono text-slate-300 space-y-2">
            {userOrder.map((line, index) => (
                <div key={index} className="flex items-center justify-between bg-slate-800 p-2 rounded">
                    <pre><code>{line}</code></pre>
                    {!isSubmitted && (
                         <div className="flex gap-1">
                            <button onClick={() => moveLine(index, 'up')} disabled={index === 0} className="px-2 py-1 text-xs bg-slate-700 rounded disabled:opacity-50 hover:bg-slate-600">▲</button>
                            <button onClick={() => moveLine(index, 'down')} disabled={index === userOrder.length - 1} className="px-2 py-1 text-xs bg-slate-700 rounded disabled:opacity-50 hover:bg-slate-600">▼</button>
                        </div>
                    )}
                </div>
            ))}
        </div>
      </div>
      
      {!isSubmitted && (
         <button
            onClick={handleSubmit}
            className="mt-4 w-full bg-cyan-600 text-white font-bold py-3 px-4 rounded-lg hover:bg-cyan-700 transition-colors"
          >
            Check Answer
          </button>
      )}

      {isSubmitted && (
        <div className={`mt-6 p-4 rounded-lg animate-fade-in ${isCorrect ? 'bg-green-900/50' : 'bg-red-900/50'}`}>
          <h3 className={`font-bold text-lg mb-2 ${isCorrect ? 'text-green-400' : 'text-red-400'}`}>
            {isCorrect ? 'Correct!' : 'Incorrect'}
          </h3>
          <p className="text-slate-300 mb-4">{challenge.explanation}</p>
          {isCorrect && (
             <button
                onClick={() => onComplete(true)}
                className="mt-4 w-full bg-purple-600 text-white font-bold py-3 px-4 rounded-lg hover:bg-purple-700 transition-colors"
            >
                Continue
            </button>
          )}
           {!isCorrect && (
             <p className="text-center text-slate-400">You lost a life. The app will hang here if you run out of lives, until the game over screen appears.</p>
          )}
        </div>
      )}
    </div>
  );
};

export default CodeScrambleMiniGame;

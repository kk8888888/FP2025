// This file has been deprecated to resolve a circular dependency.
// Gift constants are now defined in `constants.ts` as pure data.
